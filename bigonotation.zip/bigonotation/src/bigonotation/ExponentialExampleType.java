package bigonotation;

public enum ExponentialExampleType {
	 
	    
	        Fibonacci
	    

}
