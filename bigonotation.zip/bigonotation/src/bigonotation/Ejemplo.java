package bigonotation;


public class Ejemplo {

	public static void main(String[] args) {
		hola
	}
}
